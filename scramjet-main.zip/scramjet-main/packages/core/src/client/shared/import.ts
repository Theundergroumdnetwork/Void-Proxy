import { ScramjetClient } from "@client/index";
import { Object_defineProperty, _URL } from "@/shared/snapshot";

export default function (client: ScramjetClient, self: Self) {
	const boundimport = client.natives.call(
		"Function",
		null,
		"url",
		"return import(url)"
	);

	Object_defineProperty(self, client.config.globals.importfn, {
		value: function (base: string, url: string) {
			const resolved = new _URL(url, base).href;

			if (
				url.includes(":") ||
				url.startsWith("/") ||
				url.startsWith(".") ||
				url.startsWith("..")
			) {
				// this is a url
				return boundimport(
					client.rewriteUrl(resolved, { moduleType: "module" })
				);
			} else {
				// this is a specifier handled by importmaps
				return boundimport(url);
			}
		},
		writable: false,
		configurable: false,
		enumerable: false,
	});
	Object_defineProperty(self, client.config.globals.metafn, {
		value: function (metaobj: any, base: string) {
			metaobj.url = base;
			metaobj.resolve = function (url: string) {
				return new _URL(url, base).href;
			};

			return metaobj;
		},
		writable: false,
		configurable: false,
		enumerable: false,
	});
}
